import os
import pandas as pd
import matplotlib.pyplot as plt


ARQUIVO_ENTRADA = "resultados.csv"
PASTA_GRAFICOS = "graficos"
ARQUIVO_RESUMO = "resumo_resultados.csv"

TOTAL_EXECUCOES = 0


def carregar_dados():

    global TOTAL_EXECUCOES

    if not os.path.exists(ARQUIVO_ENTRADA):
        print(f"Arquivo '{ARQUIVO_ENTRADA}' não encontrado.")
        return None

    df = pd.read_csv(ARQUIVO_ENTRADA)

    TOTAL_EXECUCOES = df["Rodada"].nunique()

    print("\nArquivo carregado com sucesso.")
    print(f"Quantidade de registros: {len(df)}")
    print(f"Quantidade de execuções: {TOTAL_EXECUCOES}")

    print("\nColunas encontradas:")

    for coluna in df.columns:
        print(f" - {coluna}")

    return df


def preparar_dados(df):

    if "MemoriaRAM_bytes" in df.columns:

        df["MemoriaRAM_MB"] = (
            df["MemoriaRAM_bytes"]
            / (1024 * 1024)
        )

    return df


def gerar_resumo(df):

    metricas = {
        "LatenciaMedia_us": "Latência (µs)",
        "Throughput_MB_s": "Throughput (MB/s)",
        "MemoriaRAM_MB": "Memória RAM (MB)",
        "TempoGeracaoChave_us": "Geração de chave (µs)"
    }

    if "CPU_percent" in df.columns:
        metricas["CPU_percent"] = "CPU (%)"

    resultados = []

    for algoritmo, grupo in df.groupby("Algoritmo"):

        for coluna, nome in metricas.items():

            if coluna not in grupo.columns:
                continue

            valores = grupo[coluna].dropna()

            if len(valores) == 0:
                continue

            resultados.append({
                "Algoritmo": algoritmo,
                "Metrica": nome,
                "Menor": valores.min(),
                "Media": valores.mean(),
                "Maior": valores.max(),
                "DesvioPadrao": valores.std()
            })

    resumo = pd.DataFrame(resultados)

    resumo.to_csv(
        ARQUIVO_RESUMO,
        index=False,
        encoding="utf-8-sig"
    )

    return resumo


def mostrar_resumo(resumo):

    print("\n")
    print("=" * 90)
    print("RESUMO ESTATÍSTICO DOS ALGORITMOS")
    print("=" * 90)

    for algoritmo in resumo["Algoritmo"].unique():

        print(f"\n{algoritmo}")
        print("-" * 90)

        dados = resumo[
            resumo["Algoritmo"] == algoritmo
        ]

        for _, linha in dados.iterrows():

            print(
                f"{linha['Metrica']:<25}"
                f" | Menor: {linha['Menor']:.6f}"
                f" | Média: {linha['Media']:.6f}"
                f" | Maior: {linha['Maior']:.6f}"
                f" | Desvio padrão: {linha['DesvioPadrao']:.6f}"
            )


def criar_grafico(
    resumo,
    metrica,
    titulo,
    ylabel,
    arquivo
):
    dados = resumo[
        resumo["Metrica"] == metrica
    ].copy()

    if dados.empty:
        return

    algoritmos = dados["Algoritmo"].tolist()
    medias = dados["Media"].tolist()
    desvios = dados["DesvioPadrao"].fillna(0).tolist()
    minimos = dados["Menor"].tolist()
    maximos = dados["Maior"].tolist()

    x = list(range(len(algoritmos)))

    valores_positivos = [
        valor
        for valor in medias
        if valor > 0
    ]

    if not valores_positivos:
        return

    maior_media = max(valores_positivos)
    menor_media = min(valores_positivos)

    razao = maior_media / menor_media

    usar_log = razao >= 100

    fig, ax = plt.subplots(
        figsize=(12, 8)
    )

    if usar_log:

        erros_inferiores = []
        erros_superiores = []

        for media, desvio in zip(
            medias,
            desvios
        ):

            limite_inferior = (
                media - desvio
            )

            if limite_inferior <= 0:
                limite_inferior = (
                    media * 0.1
                )

            erros_inferiores.append(
                media - limite_inferior
            )

            erros_superiores.append(
                desvio
            )

        ax.errorbar(
            x,
            medias,
            yerr=[
                erros_inferiores,
                erros_superiores
            ],
            fmt="o",
            markersize=9,
            capsize=8,
            capthick=1.5,
            elinewidth=1.8
        )

        ax.set_yscale("log")

        valores_limite = []

        for media, desvio in zip(
            medias,
            desvios
        ):

            if media > 0:
                valores_limite.append(
                    media
                )

            if media - desvio > 0:
                valores_limite.append(
                    media - desvio
                )

            if media + desvio > 0:
                valores_limite.append(
                    media + desvio
                )

        menor = min(valores_limite)
        maior = max(valores_limite)

        ax.set_ylim(
            menor / 2,
            maior * 2
        )

        ylabel_final = (
            ylabel +
            " - escala logarítmica"
        )

    else:

        ax.errorbar(
            x,
            medias,
            yerr=desvios,
            fmt="o",
            markersize=9,
            capsize=8,
            capthick=1.5,
            elinewidth=1.8
        )

        inferiores = [
            max(
                0,
                media - desvio
            )
            for media, desvio
            in zip(
                medias,
                desvios
            )
        ]

        superiores = [
            media + desvio
            for media, desvio
            in zip(
                medias,
                desvios
            )
        ]

        menor = min(inferiores)
        maior = max(superiores)

        intervalo = maior - menor

        if intervalo <= 0:

            intervalo = max(
                abs(maior) * 0.20,
                1
            )

        margem = (
            intervalo * 0.15
        )

        limite_inferior = max(
            0,
            menor - margem
        )

        limite_superior = (
            maior + margem
        )

        ax.set_ylim(
            limite_inferior,
            limite_superior
        )

        ylabel_final = ylabel

    ax.set_xticks(x)

    ax.set_xticklabels(
        algoritmos,
        rotation=10
    )

    ax.set_xlabel(
        "Algoritmo"
    )

    ax.set_ylabel(
        ylabel_final
    )

    ax.set_title(
        f"{titulo}\n"
        f"Média ± desvio padrão de "
        f"{TOTAL_EXECUCOES} execuções"
    )

    ax.grid(
        axis="y",
        linestyle="--",
        alpha=0.35
    )

    for i, media in enumerate(
        medias
    ):

        ax.annotate(
            f"{media:.3f}",
            (
                x[i],
                media
            ),
            xytext=(
                10,
                0
            ),
            textcoords="offset points",
            fontsize=9,
            va="center"
        )

    tabela_dados = []

    for algoritmo, media, minimo, maximo in zip(
        algoritmos,
        medias,
        minimos,
        maximos
    ):

        tabela_dados.append([
            algoritmo,
            f"{media:.3f}",
            f"{minimo:.3f}",
            f"{maximo:.3f}"
        ])

    tabela = plt.table(
        cellText=tabela_dados,
        colLabels=[
            "Algoritmo",
            "Média",
            "Mínimo",
            "Máximo"
        ],
        cellLoc="center",
        colLoc="center",
        loc="bottom",
        bbox=[
            0.10,
            -0.43,
            0.80,
            0.25
        ]
    )

    tabela.auto_set_font_size(
        False
    )

    tabela.set_fontsize(
        9
    )

    tabela.scale(
        1,
        1.4
    )

    plt.subplots_adjust(
        bottom=0.36
    )

    plt.savefig(
        os.path.join(
            PASTA_GRAFICOS,
            arquivo
        ),
        dpi=300,
        bbox_inches="tight",
        pad_inches=0.25
    )

    plt.close()

def gerar_graficos(resumo):

    os.makedirs(
        PASTA_GRAFICOS,
        exist_ok=True
    )

    criar_grafico(
        resumo,
        "Latência (µs)",
        "Comparação da Latência dos Algoritmos",
        "Latência (µs)",
        "latencia.png"
    )

    criar_grafico(
        resumo,
        "Throughput (MB/s)",
        "Comparação do Throughput dos Algoritmos",
        "Throughput (MB/s)",
        "throughput.png"
    )

    criar_grafico(
        resumo,
        "Memória RAM (MB)",
        "Comparação do Consumo de Memória RAM",
        "Memória RAM (MB)",
        "memoria_ram.png"
    )

    criar_grafico(
        resumo,
        "Geração de chave (µs)",
        "Comparação do Tempo de Geração de Chaves",
        "Tempo de geração (µs)",
        "geracao_chaves.png"
    )

    if "CPU (%)" in resumo["Metrica"].values:

        criar_grafico(
            resumo,
            "CPU (%)",
            "Comparação do Uso de CPU",
            "Utilização da CPU (%)",
            "cpu.png"
        )


def mostrar_melhores(resumo):

    print("\n")
    print("=" * 75)
    print("COMPARAÇÃO ENTRE OS ALGORITMOS")
    print("=" * 75)

    latencia = resumo[
        resumo["Metrica"] == "Latência (µs)"
    ]

    if not latencia.empty:

        melhor = latencia.loc[
            latencia["Media"].idxmin()
        ]

        pior = latencia.loc[
            latencia["Media"].idxmax()
        ]

        print("\nLATÊNCIA")

        print(
            f"Melhor média: "
            f"{melhor['Algoritmo']} "
            f"({melhor['Media']:.6f} µs)"
        )

        print(
            f"Maior média: "
            f"{pior['Algoritmo']} "
            f"({pior['Media']:.6f} µs)"
        )

    throughput = resumo[
        resumo["Metrica"] == "Throughput (MB/s)"
    ]

    if not throughput.empty:

        melhor = throughput.loc[
            throughput["Media"].idxmax()
        ]

        pior = throughput.loc[
            throughput["Media"].idxmin()
        ]

        print("\nTHROUGHPUT")

        print(
            f"Melhor média: "
            f"{melhor['Algoritmo']} "
            f"({melhor['Media']:.6f} MB/s)"
        )

        print(
            f"Menor média: "
            f"{pior['Algoritmo']} "
            f"({pior['Media']:.6f} MB/s)"
        )

    ram = resumo[
        resumo["Metrica"] == "Memória RAM (MB)"
    ]

    if not ram.empty:

        melhor = ram.loc[
            ram["Media"].idxmin()
        ]

        pior = ram.loc[
            ram["Media"].idxmax()
        ]

        print("\nMEMÓRIA RAM")

        print(
            f"Menor consumo médio: "
            f"{melhor['Algoritmo']} "
            f"({melhor['Media']:.6f} MB)"
        )

        print(
            f"Maior consumo médio: "
            f"{pior['Algoritmo']} "
            f"({pior['Media']:.6f} MB)"
        )

    cpu = resumo[
        resumo["Metrica"] == "CPU (%)"
    ]

    if not cpu.empty:

        melhor = cpu.loc[
            cpu["Media"].idxmin()
        ]

        pior = cpu.loc[
            cpu["Media"].idxmax()
        ]

        print("\nCPU")

        print(
            f"Menor utilização média: "
            f"{melhor['Algoritmo']} "
            f"({melhor['Media']:.2f}%)"
        )

        print(
            f"Maior utilização média: "
            f"{pior['Algoritmo']} "
            f"({pior['Media']:.2f}%)"
        )


def main():

    print(
        "\n=========================================="
    )

    print(
        " ANÁLISE DOS RESULTADOS CRIPTOGRÁFICOS"
    )

    print(
        "=========================================="
    )

    df = carregar_dados()

    if df is None:
        return

    df = preparar_dados(df)

    resumo = gerar_resumo(df)

    mostrar_resumo(resumo)

    mostrar_melhores(resumo)

    gerar_graficos(resumo)

    print(
        "\n=========================================="
    )

    print(
        "ANÁLISE FINALIZADA"
    )

    print(
        f"Resumo: {ARQUIVO_RESUMO}"
    )

    print(
        f"Gráficos: {PASTA_GRAFICOS}/"
    )

    print(
        "==========================================\n"
    )


if __name__ == "__main__":
    main()