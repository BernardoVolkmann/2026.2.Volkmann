/* TCC: recebe quadro CAN 0x123 e mede SOMENTE cifragem no GPIO2.
   ESP32 classico + transceptor CAN (ex. SN65HVD230), Arduino-ESP32 2.x/3.x.
   Algoritmos: 1 AES-128-CTR; 2 ChaCha20; 3 RSA-2048-OAEP; 4 ECIES-P256 experimental.
   IMPORTANTE: tempos sao do ESP32, NAO devem ser igualados aos resultados do PC.
*/
#include <Arduino.h>
#include "driver/twai.h"
#include "mbedtls/aes.h"
#include "mbedtls/chacha20.h"
#include "mbedtls/entropy.h"
#include "mbedtls/ctr_drbg.h"
#include "mbedtls/rsa.h"
#include "mbedtls/ecdh.h"
#include "mbedtls/ecp.h"
#include "mbedtls/gcm.h"
#include "mbedtls/sha256.h"
#include "esp_timer.h"
#include "mbedtls/version.h"

#define ALGORITMO 1 // 1=AES-128-CTR; 2=ChaCha20; 3=RSA-2048-OAEP; 4=ECIES-P256
#define CAN_ID 0x123
#define CAN_TX GPIO_NUM_5
#define CAN_RX GPIO_NUM_4
#define PINO_PULSO 2
#define TAMANHO_DADOS 6

static mbedtls_entropy_context entropy;
static mbedtls_ctr_drbg_context drbg;
static mbedtls_aes_context aes;
static mbedtls_chacha20_context chacha;
static mbedtls_rsa_context rsa;
static mbedtls_ecp_group grupo;
static mbedtls_mpi chavePrivadaDest, chavePublicaEfem, segredo;
static mbedtls_ecp_point chavePublicaDest, pontoEfem;
static mbedtls_gcm_context gcm;
static uint8_t chaveAES[16] = {0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a,0x0b,0x0c,0x0d,0x0e,0x0f,0x10};
static uint8_t chaveChaCha[32] = {0};
static uint8_t nonce[12] = {0};
static uint8_t saida[256];
static uint8_t tag[16];
static volatile uint8_t marcador = 0;
static uint32_t contador = 0;

static void verificar(int ret, const char *onde) {
  if (ret != 0) { Serial.printf("Erro em %s: %d\n", onde, ret); while(true) delay(1000); }
}

static void preparar() {
  mbedtls_entropy_init(&entropy);
  mbedtls_ctr_drbg_init(&drbg);
  const char *personalizacao = "CAN_TCC_ESP32";
  verificar(mbedtls_ctr_drbg_seed(&drbg, mbedtls_entropy_func, &entropy,
    (const unsigned char*)personalizacao, strlen(personalizacao)), "RNG");
#if ALGORITMO == 1
  mbedtls_aes_init(&aes);
  verificar(mbedtls_aes_setkey_enc(&aes, chaveAES, 128), "AES chave");
#elif ALGORITMO == 2
  mbedtls_chacha20_init(&chacha);
  verificar(mbedtls_chacha20_setkey(&chacha, chaveChaCha), "ChaCha chave");
#elif ALGORITMO == 3
  #if MBEDTLS_VERSION_MAJOR >= 3
  mbedtls_rsa_init(&rsa);
  #else
  mbedtls_rsa_init(&rsa, MBEDTLS_RSA_PKCS_V21, MBEDTLS_MD_SHA256);
  #endif
  verificar(mbedtls_rsa_gen_key(&rsa, mbedtls_ctr_drbg_random, &drbg, 2048, 65537), "RSA chave");
  mbedtls_rsa_set_padding(&rsa, MBEDTLS_RSA_PKCS_V21, MBEDTLS_MD_SHA256);
#elif ALGORITMO == 4
  mbedtls_ecp_group_init(&grupo);
  mbedtls_mpi_init(&chavePrivadaDest);
  mbedtls_mpi_init(&chavePublicaEfem);
  mbedtls_mpi_init(&segredo);
  mbedtls_ecp_point_init(&chavePublicaDest);
  mbedtls_ecp_point_init(&pontoEfem);
  mbedtls_gcm_init(&gcm);
  verificar(mbedtls_ecp_group_load(&grupo, MBEDTLS_ECP_DP_SECP256R1), "P256 grupo");
  verificar(mbedtls_ecp_gen_keypair(&grupo, &chavePrivadaDest, &chavePublicaDest,
    mbedtls_ctr_drbg_random, &drbg), "P256 destinatario");
#else
  #error "ALGORITMO invalido"
#endif
}

static int cifrar(const uint8_t *entrada, size_t tamanho) {
#if ALGORITMO == 1
  uint8_t iv[16] = {0};
  memcpy(iv, nonce, 12);
  size_t deslocamento = 0;
  uint8_t bloco[16] = {0};
  return mbedtls_aes_crypt_ctr(&aes, tamanho, &deslocamento, iv, bloco, entrada, saida);
#elif ALGORITMO == 2
  int ret = mbedtls_chacha20_starts(&chacha, nonce, 0);
  if (ret != 0) return ret;
  return mbedtls_chacha20_update(&chacha, tamanho, entrada, saida);
#elif ALGORITMO == 3
  return mbedtls_rsa_rsaes_oaep_encrypt(&rsa, mbedtls_ctr_drbg_random, &drbg,
    MBEDTLS_RSA_PUBLIC, NULL, 0, tamanho, entrada, saida);
#elif ALGORITMO == 4
  // ECIES experimental: chave efemera P256 + ECDH + SHA256 + AES-128-GCM.
  // Inclui geracao de chave efemera na janela medida.
  int ret = mbedtls_ecp_gen_keypair(&grupo, &chavePublicaEfem, &pontoEfem,
    mbedtls_ctr_drbg_random, &drbg);
  if (ret != 0) return ret;
  ret = mbedtls_ecdh_compute_shared(&grupo, &segredo, &chavePublicaDest,
    &chavePublicaEfem, mbedtls_ctr_drbg_random, &drbg);
  if (ret != 0) return ret;
  uint8_t compartilhado[32] = {0}, hash[32] = {0};
  ret = mbedtls_mpi_write_binary(&segredo, compartilhado, sizeof(compartilhado));
  if (ret != 0) return ret;
  #if MBEDTLS_VERSION_MAJOR >= 3
  ret = mbedtls_sha256(compartilhado, sizeof(compartilhado), hash, 0);
  #else
  ret = mbedtls_sha256_ret(compartilhado, sizeof(compartilhado), hash, 0);
  #endif
  if (ret != 0) return ret;
  ret = mbedtls_gcm_setkey(&gcm, MBEDTLS_CIPHER_ID_AES, hash, 128);
  if (ret != 0) return ret;
  return mbedtls_gcm_crypt_and_tag(&gcm, MBEDTLS_GCM_ENCRYPT,
    tamanho, nonce, sizeof(nonce), NULL, 0, entrada, saida, sizeof(tag), tag);
#endif
}

void setup() {
  Serial.begin(115200);
  pinMode(PINO_PULSO, OUTPUT);
  digitalWrite(PINO_PULSO, LOW);
  preparar();
  twai_general_config_t geral = TWAI_GENERAL_CONFIG_DEFAULT(CAN_TX, CAN_RX, TWAI_MODE_NORMAL);
  twai_timing_config_t tempo = TWAI_TIMING_CONFIG_500KBITS(); // DEVE coincidir com Arduino
  twai_filter_config_t filtro = TWAI_FILTER_CONFIG_ACCEPT_ALL();
  esp_err_t erro = twai_driver_install(&geral, &tempo, &filtro);
  if (erro != ESP_OK) { Serial.printf("TWAI install falhou: %d\n", erro); while(true) delay(1000); }
  erro = twai_start();
  if (erro != ESP_OK) { Serial.printf("TWAI start falhou: %d\n", erro); while(true) delay(1000); }
  Serial.printf("Aguardando CAN 0x%03X, algoritmo %d, GPIO2\n", CAN_ID, ALGORITMO);
}

void loop() {
  twai_message_t msg;
  if (twai_receive(&msg, pdMS_TO_TICKS(1000)) != ESP_OK) return;
  if (msg.extd || msg.rtr || msg.identifier != CAN_ID || msg.data_length_code != TAMANHO_DADOS) return;

  // Nonce unico por mensagem: demonstracao experimental; em producao,
  // implementar persistencia e gestao de chaves/nonces contra reutilizacao.
  contador++;
  memset(nonce, 0, sizeof(nonce));
  nonce[0] = (uint8_t)(contador >> 24);
  nonce[1] = (uint8_t)(contador >> 16);
  nonce[2] = (uint8_t)(contador >> 8);
  nonce[3] = (uint8_t)contador;

  // A recepcao CAN e o preparo do nonce ficam FORA da janela medida.
  digitalWrite(PINO_PULSO, HIGH);
  int ret = cifrar(msg.data, TAMANHO_DADOS);
  digitalWrite(PINO_PULSO, LOW);

  if (ret != 0) Serial.printf("Falha cifragem: %d\n", ret);
  else {
    marcador ^= saida[0]; // evita otimizar o resultado nao utilizado
    Serial.printf("CAN 0x%03lX recebido e cifrado; seq=%lu; marcador=%u\n",
      (unsigned long)msg.identifier, (unsigned long)contador, marcador);
  }
}
