#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <psapi.h>

#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/rsa.h>

#define RODADAS 100
#define MAX_MENSAGENS 1000

typedef struct {
    unsigned int id;
    int dlc;
    unsigned char dados[8];
} MensagemCAN;


int carregarDataset(
    const char *nomeArquivo,
    MensagemCAN mensagens[]
) {
    FILE *arquivo = fopen(nomeArquivo, "r");

    if (!arquivo) {
        printf("Erro ao abrir o dataset.\n");
        return 0;
    }

    char linha[512];
    int quantidade = 0;

    while (
        fgets(linha, sizeof(linha), arquivo) &&
        quantidade < MAX_MENSAGENS
    ) {
        double timestamp;
        unsigned int id;
        unsigned int campoExtra;
        int dlc;

        int posicao = 0;

        int campos = sscanf(
            linha,
            "Timestamp: %lf ID: %x %x DLC: %d %n",
            &timestamp,
            &id,
            &campoExtra,
            &dlc,
            &posicao
        );

        if (campos != 4)
            continue;

        if (dlc <= 0 || dlc > 8)
            continue;

        mensagens[quantidade].id = id;
        mensagens[quantidade].dlc = dlc;

        char *ptr = linha + posicao;

        for (int i = 0; i < dlc; i++) {

            unsigned int byte;

            int lidos;

            if (sscanf(
                    ptr,
                    "%x%n",
                    &byte,
                    &lidos
                ) != 1) {

                break;
            }

            mensagens[quantidade].dados[i] =
                (unsigned char)byte;

            ptr += lidos;
        }

        quantidade++;
    }

    fclose(arquivo);

    return quantidade;
}


size_t obterMemoriaRAM()
{
    PROCESS_MEMORY_COUNTERS pmc;

    if (GetProcessMemoryInfo(
            GetCurrentProcess(),
            &pmc,
            sizeof(pmc))) {

        return (size_t)pmc.WorkingSetSize;
    }

    return 0;
}


double calcularTempoUs(
    LARGE_INTEGER inicio,
    LARGE_INTEGER fim,
    LARGE_INTEGER frequencia
) {
    return (
        (double)(fim.QuadPart - inicio.QuadPart)
        * 1000000.0
    ) / (double)frequencia.QuadPart;
}


int cifrarAES(
    const unsigned char *dados,
    int tamanho,
    const unsigned char *chave,
    const unsigned char *iv,
    unsigned char *saida
) {
    EVP_CIPHER_CTX *ctx =
        EVP_CIPHER_CTX_new();

    if (!ctx)
        return -1;

    int len = 0;
    int total = 0;

    if (EVP_EncryptInit_ex(
            ctx,
            EVP_aes_128_ctr(),
            NULL,
            chave,
            iv) != 1) {

        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    if (EVP_EncryptUpdate(
            ctx,
            saida,
            &len,
            dados,
            tamanho) != 1) {

        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    total = len;

    if (EVP_EncryptFinal_ex(
            ctx,
            saida + total,
            &len) != 1) {

        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    total += len;

    EVP_CIPHER_CTX_free(ctx);

    return total;
}


int cifrarChaCha20(
    const unsigned char *dados,
    int tamanho,
    const unsigned char *chave,
    const unsigned char *nonce,
    unsigned char *saida
) {
    EVP_CIPHER_CTX *ctx =
        EVP_CIPHER_CTX_new();

    if (!ctx)
        return -1;

    int len = 0;
    int total = 0;

    if (EVP_EncryptInit_ex(
            ctx,
            EVP_chacha20(),
            NULL,
            chave,
            nonce) != 1) {

        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    if (EVP_EncryptUpdate(
            ctx,
            saida,
            &len,
            dados,
            tamanho) != 1) {

        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    total = len;

    if (EVP_EncryptFinal_ex(
            ctx,
            saida + total,
            &len) != 1) {

        EVP_CIPHER_CTX_free(ctx);
        return -1;
    }

    total += len;

    EVP_CIPHER_CTX_free(ctx);

    return total;
}


int cifrarRSA(
    EVP_PKEY *chavePublica,
    const unsigned char *dados,
    size_t tamanho,
    unsigned char *saida,
    size_t *tamanhoSaida
) {
    EVP_PKEY_CTX *ctx =
        EVP_PKEY_CTX_new(chavePublica, NULL);

    if (!ctx)
        return 0;

    if (EVP_PKEY_encrypt_init(ctx) <= 0) {
        EVP_PKEY_CTX_free(ctx);
        return 0;
    }

    if (EVP_PKEY_CTX_set_rsa_padding(
            ctx,
            RSA_PKCS1_OAEP_PADDING) <= 0) {

        EVP_PKEY_CTX_free(ctx);
        return 0;
    }

    if (EVP_PKEY_encrypt(
            ctx,
            NULL,
            tamanhoSaida,
            dados,
            tamanho) <= 0) {

        EVP_PKEY_CTX_free(ctx);
        return 0;
    }

    if (EVP_PKEY_encrypt(
            ctx,
            saida,
            tamanhoSaida,
            dados,
            tamanho) <= 0) {

        EVP_PKEY_CTX_free(ctx);
        return 0;
    }

    EVP_PKEY_CTX_free(ctx);

    return 1;
}



int cifrarECIES(
    EVP_PKEY *chaveA,
    EVP_PKEY *chaveB,
    const unsigned char *dados,
    int tamanhoDados,
    unsigned char *saida,
    int *tamanhoSaida
) {
    EVP_PKEY_CTX *ctxECDH = NULL;
    EVP_MD_CTX *ctxHash = NULL;
    EVP_CIPHER_CTX *ctxAES = NULL;

    unsigned char segredo[128];
    size_t tamanhoSegredo = sizeof(segredo);

    unsigned char hash[32];
    unsigned int tamanhoHash = 0;

    unsigned char chaveAES[16];
    unsigned char iv[12];
    unsigned char tag[16];

    int len = 0;
    int total = 0;


    

    ctxECDH = EVP_PKEY_CTX_new(chaveA, NULL);

    if (!ctxECDH)
        goto erro;

    if (EVP_PKEY_derive_init(ctxECDH) <= 0)
        goto erro;

    if (EVP_PKEY_derive_set_peer(
            ctxECDH,
            chaveB) <= 0)
        goto erro;

    if (EVP_PKEY_derive(
            ctxECDH,
            NULL,
            &tamanhoSegredo) <= 0)
        goto erro;

    if (EVP_PKEY_derive(
            ctxECDH,
            segredo,
            &tamanhoSegredo) <= 0)
        goto erro;


    

    ctxHash = EVP_MD_CTX_new();

    if (!ctxHash)
        goto erro;

    if (EVP_DigestInit_ex(
            ctxHash,
            EVP_sha256(),
            NULL) != 1)
        goto erro;

    if (EVP_DigestUpdate(
            ctxHash,
            segredo,
            tamanhoSegredo) != 1)
        goto erro;

    if (EVP_DigestFinal_ex(
            ctxHash,
            hash,
            &tamanhoHash) != 1)
        goto erro;

    memcpy(
        chaveAES,
        hash,
        16
    );



    if (RAND_bytes(
            iv,
            sizeof(iv)) != 1)
        goto erro;


    

    ctxAES = EVP_CIPHER_CTX_new();

    if (!ctxAES)
        goto erro;

    if (EVP_EncryptInit_ex(
            ctxAES,
            EVP_aes_128_gcm(),
            NULL,
            NULL,
            NULL) != 1)
        goto erro;

    if (EVP_CIPHER_CTX_ctrl(
            ctxAES,
            EVP_CTRL_GCM_SET_IVLEN,
            sizeof(iv),
            NULL) != 1)
        goto erro;

    if (EVP_EncryptInit_ex(
            ctxAES,
            NULL,
            NULL,
            chaveAES,
            iv) != 1)
        goto erro;

    if (EVP_EncryptUpdate(
            ctxAES,
            saida,
            &len,
            dados,
            tamanhoDados) != 1)
        goto erro;

    total = len;

    if (EVP_EncryptFinal_ex(
            ctxAES,
            saida + total,
            &len) != 1)
        goto erro;

    total += len;



    if (EVP_CIPHER_CTX_ctrl(
            ctxAES,
            EVP_CTRL_GCM_GET_TAG,
            sizeof(tag),
            tag) != 1)
        goto erro;

    memcpy(
        saida + total,
        tag,
        sizeof(tag)
    );

    total += sizeof(tag);

    *tamanhoSaida = total;


    EVP_PKEY_CTX_free(ctxECDH);
    EVP_MD_CTX_free(ctxHash);
    EVP_CIPHER_CTX_free(ctxAES);

    return 1;


erro:

    EVP_PKEY_CTX_free(ctxECDH);
    EVP_MD_CTX_free(ctxHash);
    EVP_CIPHER_CTX_free(ctxAES);

    return 0;
}


/* ============================================================
   GERAÇÃO DAS CHAVES RSA
   ============================================================ */
EVP_PKEY *gerarChaveRSA()
{
    return EVP_PKEY_Q_keygen(
        NULL,
        NULL,
        "RSA",
        (size_t)2048
    );
}


/* ============================================================
   GERAÇÃO DAS CHAVES ECC
   ============================================================ */
EVP_PKEY *gerarChaveECC()
{
    return EVP_PKEY_Q_keygen(
        NULL,
        NULL,
        "EC",
        "P-256"
    );
}


/* ============================================================
   SALVAR RESULTADO
   ============================================================ */
void salvarResultado(
    FILE *csv,
    const char *algoritmo,
    int rodada,
    int mensagens,
    long long bytes,
    double tempoTotalUs,
    double tempoChaveUs,
    size_t memoria
) {
    double latenciaMedia =
        tempoTotalUs / mensagens;

    double segundos =
        tempoTotalUs / 1000000.0;

    double throughput = 0;

    if (segundos > 0) {
        throughput =
            ((double)bytes / (1024.0 * 1024.0))
            / segundos;
    }

    fprintf(
        csv,
        "%s,%d,%d,%lld,%.6f,%.6f,%.6f,%.6f,%zu\n",

        algoritmo,
        rodada,
        mensagens,
        bytes,
        tempoTotalUs,
        latenciaMedia,
        throughput,
        tempoChaveUs,
        memoria
    );
}


int main(int argc, char *argv[])
{
    if (argc < 2) {
        printf(
            "Uso:\n"
            "benchmark.exe dataset.txt\n"
        );

        return 1;
    }

    MensagemCAN mensagens[MAX_MENSAGENS];

    int quantidade =
        carregarDataset(
            argv[1],
            mensagens
        );

    if (quantidade == 0) {
        printf(
            "Nenhuma mensagem CAN valida encontrada.\n"
        );

        return 1;
    }

    printf(
        "%d mensagens CAN carregadas.\n\n",
        quantidade
    );

    FILE *csv =
        fopen(
            "resultados.csv",
            "w"
        );

    if (!csv) {
        printf(
            "Erro ao criar resultados.csv\n"
        );

        return 1;
    }

    fprintf(
        csv,
        "Algoritmo,"
        "Rodada,"
        "Mensagens,"
        "BytesProcessados,"
        "TempoTotal_us,"
        "LatenciaMedia_us,"
        "Throughput_MB_s,"
        "TempoGeracaoChave_us,"
        "MemoriaRAM_bytes\n"
    );

    LARGE_INTEGER frequencia;

    QueryPerformanceFrequency(
        &frequencia
    );

    for (int rodada = 1;
         rodada <= RODADAS;
         rodada++) {

        printf(
            "Rodada %d/%d\n",
            rodada,
            RODADAS
        );

        LARGE_INTEGER inicio;
        LARGE_INTEGER fim;
        LARGE_INTEGER inicioChave;
        LARGE_INTEGER fimChave;

        unsigned char chaveAES[16];

        QueryPerformanceCounter(
            &inicioChave
        );

        RAND_bytes(
            chaveAES,
            sizeof(chaveAES)
        );

        QueryPerformanceCounter(
            &fimChave
        );

        double tempoChaveAES =
            calcularTempoUs(
                inicioChave,
                fimChave,
                frequencia
            );

        long long bytesAES = 0;

        QueryPerformanceCounter(
            &inicio
        );

        for (int i = 0;
             i < quantidade;
             i++) {

            unsigned char iv[16];
            unsigned char saida[32];

            RAND_bytes(
                iv,
                sizeof(iv)
            );

            int tamanhoSaida =
                cifrarAES(
                    mensagens[i].dados,
                    mensagens[i].dlc,
                    chaveAES,
                    iv,
                    saida
                );

            if (tamanhoSaida < 0) {
                printf("Erro AES.\n");

                fclose(csv);

                return 1;
            }

            bytesAES +=
                mensagens[i].dlc;
        }

        QueryPerformanceCounter(
            &fim
        );

        double tempoAES =
            calcularTempoUs(
                inicio,
                fim,
                frequencia
            );

        salvarResultado(
            csv,
            "AES-128-CTR",
            rodada,
            quantidade,
            bytesAES,
            tempoAES,
            tempoChaveAES,
            obterMemoriaRAM()
        );


        unsigned char chaveChaCha[32];

        QueryPerformanceCounter(
            &inicioChave
        );

        RAND_bytes(
            chaveChaCha,
            sizeof(chaveChaCha)
        );

        QueryPerformanceCounter(
            &fimChave
        );

        double tempoChaveChaCha =
            calcularTempoUs(
                inicioChave,
                fimChave,
                frequencia
            );

        long long bytesChaCha = 0;

        QueryPerformanceCounter(
            &inicio
        );

        for (int i = 0;
             i < quantidade;
             i++) {

            unsigned char nonce[16];
            unsigned char saida[32];

            RAND_bytes(
                nonce,
                sizeof(nonce)
            );

            int tamanhoSaida =
                cifrarChaCha20(
                    mensagens[i].dados,
                    mensagens[i].dlc,
                    chaveChaCha,
                    nonce,
                    saida
                );

            if (tamanhoSaida < 0) {
                printf(
                    "Erro ChaCha20.\n"
                );

                fclose(csv);

                return 1;
            }

            bytesChaCha +=
                mensagens[i].dlc;
        }

        QueryPerformanceCounter(
            &fim
        );

        double tempoChaCha =
            calcularTempoUs(
                inicio,
                fim,
                frequencia
            );

        salvarResultado(
            csv,
            "ChaCha20",
            rodada,
            quantidade,
            bytesChaCha,
            tempoChaCha,
            tempoChaveChaCha,
            obterMemoriaRAM()
        );


        QueryPerformanceCounter(
            &inicioChave
        );

        EVP_PKEY *rsa =
            gerarChaveRSA();

        QueryPerformanceCounter(
            &fimChave
        );

        if (!rsa) {
            printf(
                "Erro ao gerar chave RSA.\n"
            );

            fclose(csv);

            return 1;
        }

        double tempoChaveRSA =
            calcularTempoUs(
                inicioChave,
                fimChave,
                frequencia
            );

        long long bytesRSA = 0;

        QueryPerformanceCounter(
            &inicio
        );

        for (int i = 0;
             i < quantidade;
             i++) {

            unsigned char saida[256];

            size_t tamanhoSaida =
                sizeof(saida);

            if (!cifrarRSA(
                    rsa,
                    mensagens[i].dados,
                    mensagens[i].dlc,
                    saida,
                    &tamanhoSaida)) {

                printf(
                    "Erro RSA.\n"
                );

                EVP_PKEY_free(rsa);

                fclose(csv);

                return 1;
            }

            bytesRSA +=
                mensagens[i].dlc;
        }

        QueryPerformanceCounter(
            &fim
        );

        double tempoRSA =
            calcularTempoUs(
                inicio,
                fim,
                frequencia
            );

        salvarResultado(
            csv,
            "RSA-2048-OAEP",
            rodada,
            quantidade,
            bytesRSA,
            tempoRSA,
            tempoChaveRSA,
            obterMemoriaRAM()
        );

        EVP_PKEY_free(rsa);


        QueryPerformanceCounter(
            &inicioChave
        );

        EVP_PKEY *eccA =
            gerarChaveECC();

        EVP_PKEY *eccB =
            gerarChaveECC();

        QueryPerformanceCounter(
            &fimChave
        );

        if (!eccA || !eccB) {
            printf(
                "Erro ao gerar chaves ECC.\n"
            );

            EVP_PKEY_free(eccA);
            EVP_PKEY_free(eccB);

            fclose(csv);

            return 1;
        }

        double tempoChaveECC =
            calcularTempoUs(
                inicioChave,
                fimChave,
                frequencia
            );

        long long bytesECC = 0;

        QueryPerformanceCounter(
            &inicio
        );

        for (int i = 0;
             i < quantidade;
             i++) {

            unsigned char saida[64];

            int tamanhoSaida = 0;

            if (!cifrarECIES(
                    eccA,
                    eccB,
                    mensagens[i].dados,
                    mensagens[i].dlc,
                    saida,
                    &tamanhoSaida)) {

                printf(
                    "Erro ECIES.\n"
                );

                EVP_PKEY_free(eccA);
                EVP_PKEY_free(eccB);

                fclose(csv);

                return 1;
            }

            bytesECC +=
                mensagens[i].dlc;
        }

        QueryPerformanceCounter(
            &fim
        );

        double tempoECC =
            calcularTempoUs(
                inicio,
                fim,
                frequencia
            );

        salvarResultado(
            csv,
            "ECIES-P256",
            rodada,
            quantidade,
            bytesECC,
            tempoECC,
            tempoChaveECC,
            obterMemoriaRAM()
        );

        EVP_PKEY_free(eccA);
        EVP_PKEY_free(eccB);

        fflush(csv);
    }

    fclose(csv);

    printf(
        "\n=====================================\n"
        "Experimento finalizado.\n"
        "Rodadas executadas: %d\n"
        "Resultados: resultados.csv\n"
        "=====================================\n",
        RODADAS
    );

    return 0;
}