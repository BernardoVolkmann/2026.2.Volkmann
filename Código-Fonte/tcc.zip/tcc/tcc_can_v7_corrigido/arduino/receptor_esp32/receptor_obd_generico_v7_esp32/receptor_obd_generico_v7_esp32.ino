#include <SPI.h>
#include <mcp_can.h>

/*
  =====================================================================
  TCC V7 - RECEPTOR CAN REAL / PONTE CAN -> USB
  ESP32 + MCP2515
  =====================================================================

  Este firmware NAO simula o recebimento.
  O frame so e enviado ao computador depois de ser lido do MCP2515.

  ESP32 -> MCP2515
    GPIO18 -> SCK
    GPIO19 -> MISO
    GPIO23 -> MOSI
    GPIO27 -> CS
    GPIO4  -> INT
    GND    -> GND

  BARRAMENTO
    CANH -> CANH do transmissor
    CANL -> CANL do transmissor
    GND  -> GND comum

  Configuracao:
    CAN: 500 kbps
    MCP2515: 8 MHz

  Saida USB/Serial para o Python:
    ID=0x120 DLC=6 DATA=18 44 23 F0 00 00
*/

#define CAN_SCK  18
#define CAN_MISO 19
#define CAN_MOSI 23
#define CAN_CS   27
#define CAN_INT  4
#define MCP_CLOCK MCP_8MHZ
#define DEBUG_STATUS false

MCP_CAN CAN(CAN_CS);

uint32_t framesRx = 0;
unsigned long ultimoFrameMs = 0;
unsigned long ultimoStatusMs = 0;

void imprimirByteHex(byte value) {
  if (value < 0x10) Serial.print('0');
  Serial.print(value, HEX);
}

void publicarFrameUSB(unsigned long id, byte len, const byte *data) {
  // Formato consumido diretamente por can_interface.py.
  Serial.print(F("ID=0x"));
  Serial.print(id, HEX);
  Serial.print(F(" DLC="));
  Serial.print(len);
  Serial.print(F(" DATA="));

  for (byte i = 0; i < len; i++) {
    imprimirByteHex(data[i]);
    if (i + 1 < len) Serial.print(' ');
  }
  Serial.println();
}

void setup() {
  Serial.begin(115200);
  delay(800);

  Serial.println();
  Serial.println(F("TCC_CAN_RX_READY ESP32"));
  Serial.println(F("TCC V7 - RECEPTOR CAN REAL / CAN->USB"));
  Serial.println(F("ESP32: SCK=18 MISO=19 MOSI=23 CS=27 INT=4"));
  Serial.println(F("CAN: 500 kbps | MCP2515: 8 MHz"));

  pinMode(CAN_CS, OUTPUT);
  digitalWrite(CAN_CS, HIGH);
  pinMode(CAN_INT, INPUT_PULLUP);

  SPI.begin(CAN_SCK, CAN_MISO, CAN_MOSI, CAN_CS);

  byte initResult = CAN.begin(MCP_ANY, CAN_500KBPS, MCP_CLOCK);
  if (initResult != CAN_OK) {
    Serial.print(F("ERRO: MCP2515 receptor nao inicializado. Codigo="));
    Serial.println(initResult);
    while (1) delay(1000);
  }

  CAN.setMode(MCP_NORMAL);
  delay(50);

  Serial.println(F("MCP2515 receptor inicializado em MCP_NORMAL."));
  Serial.println(F("Aguardando frames CAN fisicos..."));

  ultimoFrameMs = millis();
  ultimoStatusMs = millis();
}

void loop() {
  // Drena todos os frames presentes nos buffers RX do MCP2515.
  while (CAN_MSGAVAIL == CAN.checkReceive()) {
    unsigned long id = 0;
    byte len = 0;
    byte data[8] = {0};

    CAN.readMsgBuf(&id, &len, data);

    // CAN classico: DLC maximo = 8. Protecao adicional contra leitura invalida.
    if (len > 8) len = 8;

    framesRx++;
    ultimoFrameMs = millis();
    publicarFrameUSB(id, len, data);
  }

  if (DEBUG_STATUS) {
    unsigned long agora = millis();
    if (agora - ultimoStatusMs >= 2000) {
      Serial.print(F("[STATUS] frames_rx="));
      Serial.print(framesRx);
      if (agora - ultimoFrameMs >= 2000) {
        Serial.print(F(" | SEM FRAMES CAN ha "));
        Serial.print((agora - ultimoFrameMs) / 1000.0f, 1);
        Serial.print(F(" s"));
      }
      Serial.println();
      ultimoStatusMs = agora;
    }
  }
}
