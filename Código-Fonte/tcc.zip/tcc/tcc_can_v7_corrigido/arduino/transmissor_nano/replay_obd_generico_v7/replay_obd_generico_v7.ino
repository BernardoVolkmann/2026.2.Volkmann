#include <SPI.h>
#include <mcp_can.h>
#include "dataset_replay_v7.h"

/*
  =====================================================================
  TCC V7 - TRANSMISSOR CAN REAL
  Arduino Nano + MCP2515
  =====================================================================

  O Nano NAO envia os dados do dataset diretamente ao computador.
  Ele converte cada amostra em 5 frames CAN e transmite pelo MCP2515.
  O computador deve ficar conectado ao RECEPTOR.

  PINAGEM Nano -> MCP2515
    D10 -> CS
    D13 -> SCK
    D12 -> MISO
    D11 -> MOSI
    D8  -> INT (nao e necessario para transmissao)
    5V  -> VCC (conforme o seu modulo)
    GND -> GND

  BARRAMENTO
    CANH -> CANH do receptor
    CANL -> CANL do receptor
    GND  -> GND comum

  Configuracao:
    CAN: 500 kbps
    MCP2515: 8 MHz
*/

#define CAN_CS 10
#define CAN_INT 8
#define MCP_CLOCK MCP_8MHZ
#define REPETIR_DATASET true
#define DEBUG_TX true

MCP_CAN CAN(CAN_CS);

const unsigned long ID_RPM_SPEED   = 0x120;
const unsigned long ID_TEMPS       = 0x121;
const unsigned long ID_MAP_MAF     = 0x122;
const unsigned long ID_THROTTLE_D  = 0x123;
const unsigned long ID_PEDAL_E_AMB = 0x124;

size_t sampleIndex = 0;
uint16_t sequenceNumber = 0;
unsigned long replayStart = 0;
uint32_t datasetStartTimestamp = 0;

// ---------------------------------------------------------------------
// Acesso portavel ao dataset.
// Arduino Nano/Uno (AVR): DATASET_OBD esta em PROGMEM e precisa das
// funcoes *_P/pgm_read_*. Em outras arquiteturas ele pode ser lido
// diretamente.
// ---------------------------------------------------------------------
void readReplaySample(size_t index, ReplaySampleOBD &sample) {
#if defined(ARDUINO_ARCH_AVR)
  memcpy_P(&sample, &DATASET_OBD[index], sizeof(ReplaySampleOBD));
#else
  memcpy(&sample, &DATASET_OBD[index], sizeof(ReplaySampleOBD));
#endif
}

uint32_t readReplayTimestamp(size_t index) {
#if defined(ARDUINO_ARCH_AVR)
  return pgm_read_dword(&DATASET_OBD[index].timestampMs);
#else
  return DATASET_OBD[index].timestampMs;
#endif
}

void putU16(byte *buf, byte pos, uint16_t value) {
  buf[pos] = (byte)((value >> 8) & 0xFF);
  buf[pos + 1] = (byte)(value & 0xFF);
}

void putI16(byte *buf, byte pos, int16_t value) {
  putU16(buf, pos, (uint16_t)value);
}

bool sendFrame(unsigned long id, const byte *data, byte len, uint16_t seq) {
  // A biblioteca recebe byte*, entao usamos um buffer local mutavel.
  byte frame[8] = {0};
  memcpy(frame, data, len);

  byte result = CAN.sendMsgBuf(id, 0, len, frame);

  if (DEBUG_TX) {
    Serial.print(result == CAN_OK ? F("[TX OK ] ") : F("[TX ERR] "));
    Serial.print(F("ID=0x"));
    Serial.print(id, HEX);
    Serial.print(F(" DLC="));
    Serial.print(len);
    Serial.print(F(" SEQ="));
    Serial.println(seq);
  }

  return result == CAN_OK;
}

void sendSample(uint16_t seq) {
  ReplaySampleOBD s;
  readReplaySample(sampleIndex, s);

  byte data[8] = {0};
  bool ok = true;

  // 0x120: RPM + velocidade + sequencia
  putU16(data, 0, s.rpm_x4);
  putU16(data, 2, s.speed_x100);
  putU16(data, 4, seq);
  ok &= sendFrame(ID_RPM_SPEED, data, 6, seq);
  delay(2);

  // 0x121: temperatura do motor + IAT + sequencia
  memset(data, 0, sizeof(data));
  putI16(data, 0, s.coolant_x100);
  putI16(data, 2, s.iat_x100);
  putU16(data, 4, seq);
  ok &= sendFrame(ID_TEMPS, data, 6, seq);
  delay(2);

  // 0x122: MAP + MAF + sequencia
  memset(data, 0, sizeof(data));
  putU16(data, 0, s.map_x100);
  putU16(data, 2, s.maf_x100);
  putU16(data, 4, seq);
  ok &= sendFrame(ID_MAP_MAF, data, 6, seq);
  delay(2);

  // 0x123: borboleta + acelerador D + sequencia
  memset(data, 0, sizeof(data));
  putU16(data, 0, s.throttle_x100);
  putU16(data, 2, s.accelD_x100);
  putU16(data, 4, seq);
  ok &= sendFrame(ID_THROTTLE_D, data, 6, seq);
  delay(2);

  // 0x124: acelerador E + temperatura ambiente + sequencia
  memset(data, 0, sizeof(data));
  putU16(data, 0, s.accelE_x100);
  putI16(data, 2, s.ambient_x100);
  putU16(data, 4, seq);
  ok &= sendFrame(ID_PEDAL_E_AMB, data, 6, seq);

  if (DEBUG_TX) {
    uint32_t relativoMs = s.timestampMs - datasetStartTimestamp;
    Serial.print(F("AMOSTRA TX seq="));
    Serial.print(seq);
    Serial.print(F(" | t_rel="));
    Serial.print(relativoMs / 1000.0f, 2);
    Serial.print(F(" s | RPM="));
    Serial.print(s.rpm_x4 / 4.0f, 1);
    Serial.print(F(" | V="));
    Serial.print(s.speed_x100 / 100.0f, 1);
    Serial.print(F(" km/h | resultado="));
    Serial.println(ok ? F("OK") : F("ERRO"));
  }
}

void reiniciarReplay() {
  sampleIndex = 0;
  sequenceNumber = 0;
  replayStart = millis();
  datasetStartTimestamp = readReplayTimestamp(0);
}

void setup() {
  Serial.begin(115200);
  delay(800);

  Serial.println();
  Serial.println(F("TCC_CAN_TX_READY NANO"));
  Serial.println(F("TCC V7 - TRANSMISSOR CAN REAL"));
  Serial.println(F("Nano: CS=D10 SCK=D13 MISO=D12 MOSI=D11 INT=D8"));
  Serial.println(F("CAN: 500 kbps | MCP2515: 8 MHz"));

  pinMode(CAN_CS, OUTPUT);
  digitalWrite(CAN_CS, HIGH);
  pinMode(CAN_INT, INPUT_PULLUP);
  SPI.begin();

  byte initResult = CAN.begin(MCP_ANY, CAN_500KBPS, MCP_CLOCK);
  if (initResult != CAN_OK) {
    Serial.print(F("ERRO: MCP2515 transmissor nao inicializado. Codigo="));
    Serial.println(initResult);
    while (1) delay(1000);
  }

  CAN.setMode(MCP_NORMAL);
  delay(50);

  Serial.println(F("MCP2515 transmissor inicializado em MCP_NORMAL."));
  Serial.print(F("Amostras no replay: "));
  Serial.println(DATASET_OBD_SIZE);

  reiniciarReplay();
}

void loop() {
  if (sampleIndex >= DATASET_OBD_SIZE) {
    if (DEBUG_TX) {
      Serial.println(F("=== FIM DO REPLAY OBD-II ==="));
    }

    if (REPETIR_DATASET) {
      if (DEBUG_TX) {
        Serial.println(F("Reiniciando replay em 2 segundos..."));
      }
      delay(2000);
      reiniciarReplay();
    } else {
      while (1) delay(1000);
    }
    return;
  }

  uint32_t sampleTimestamp = readReplayTimestamp(sampleIndex);
  uint32_t tempoRelativoMs = sampleTimestamp - datasetStartTimestamp;

  if ((uint32_t)(millis() - replayStart) >= tempoRelativoMs) {
    sendSample(sequenceNumber);
    sampleIndex++;
    sequenceNumber++;
  }
}
