TCC - CAN EM TEMPO REAL

1. Instale:
   pip install -r requirements.txt

2. Para testar sem hardware, deixe em configuracao.py:
   MODO_CAN = "simulado"

3. Execute:
   python main.py

O dashboard mostra ao vivo:
- latência de AES-128-CTR, ChaCha20, RSA-2048-OAEP e ECIES-P256;
- throughput de cada criptografia;
- intervalo real entre frames CAN.

O CSV resultados/can_tempo_real.csv recebe QUATRO linhas para cada frame CAN, uma por criptografia, contendo:
- data/hora;
- timestamp;
- intervalo CAN;
- ID;
- DLC;
- payload hexadecimal;
- algoritmo;
- latência;
- throughput;
- bytes de entrada;
- bytes de saída;
- sucesso/erro.

Quando souber o hardware, altere MODO_CAN para pcan, kvaser, vector ou socketcan. O restante do sistema permanece igual.

IMPORTANTE:
Este módulo usa Python + cryptography para o monitoramento ao vivo. O benchmark principal em C + OpenSSL deve permanecer separado para preservar a metodologia original. O ECIES-P256 aqui é ECIES-like: ECDH P-256 + SHA-256 + AES-128-GCM.
