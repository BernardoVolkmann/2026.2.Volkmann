TCC - LEITURA CAN REAL VIA RECEPTOR USB
=======================================

1. Instale:
   python -m pip install -r requirements.txt

2. Teste primeiro sem dashboard:
   python teste_receptor_serial.py

3. Se receber os IDs 0x120 a 0x124, execute:
   python main.py

4. O CSV fica em:
   resultados/can_tempo_real.csv

SERIAL_PORT="auto" procura o firmware receptor pelo marcador
TCC_CAN_RX_READY. Se necessario, defina a porta manualmente em configuracao.py.

O formato emitido pelo receptor e:
ID=0x120 DLC=6 DATA=18 44 23 F0 00 00

O transmissor nao emite esse formato pela USB. Logo, a aplicacao Python nao
confunde os logs do transmissor com frames recebidos fisicamente no CAN.
