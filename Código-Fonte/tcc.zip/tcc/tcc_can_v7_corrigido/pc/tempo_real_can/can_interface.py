from dataclasses import dataclass
from time import perf_counter, sleep
import random
import re

from configuracao import (
    MODO_CAN,
    BITRATE,
    INTERVALO_SIMULACAO_S,
    SOCKETCAN_CHANNEL,
    SOCKETCAN_INTERFACE,
    SERIAL_PORT,
    SERIAL_BAUDRATE,
    SERIAL_TIMEOUT_S,
)


@dataclass
class MensagemCAN:
    timestamp: float
    can_id: int
    dados: bytes

    @property
    def dlc(self):
        return len(self.dados)


class InterfaceCAN:
    def conectar(self):
        raise NotImplementedError

    def receber(self):
        raise NotImplementedError

    def desconectar(self):
        raise NotImplementedError


class InterfaceSimulada(InterfaceCAN):
    def conectar(self):
        self.ativa = True
        self.inicio = perf_counter()
        self.ids = [0x100, 0x123, 0x200, 0x350, 0x430]

    def receber(self):
        if not self.ativa:
            return None
        sleep(INTERVALO_SIMULACAO_S)
        can_id = random.choice(self.ids)
        dlc = random.randint(1, 8)
        dados = bytes(random.randint(0, 255) for _ in range(dlc))
        return MensagemCAN(perf_counter() - self.inicio, can_id, dados)

    def desconectar(self):
        self.ativa = False


class InterfaceSerial(InterfaceCAN):
    """
    Ponte USB do RECEPTOR CAN.

    O microcontrolador receptor le o frame fisicamente do MCP2515 e publica:
      ID=0x120 DLC=6 DATA=18 44 23 F0 00 00

    Linhas de diagnostico que nao representam frames CAN sao ignoradas.
    """

    MARCADOR_RECEPTOR = "TCC_CAN_RX_READY"

    def __init__(self, porta, baudrate):
        self.porta = porta
        self.baudrate = baudrate
        self.serial = None
        self.inicio = None

    @staticmethod
    def _portas_preferidas(list_ports):
        portas = list(list_ports.comports())
        preferidas = [
            p.device
            for p in portas
            if (
                "ttyUSB" in p.device
                or "ttyACM" in p.device
                or "COM" in p.device.upper()
            )
        ]
        return preferidas if preferidas else [p.device for p in portas]

    def _detectar_receptor(self, serial_mod, list_ports):
        portas = self._portas_preferidas(list_ports)
        if not portas:
            raise RuntimeError("Nenhuma porta serial USB encontrada.")

        if len(portas) == 1:
            print(f"Uma unica porta serial encontrada: {portas[0]}")
            return portas[0]

        print("Procurando automaticamente a USB do receptor CAN...")
        print("Portas candidatas: " + ", ".join(portas))

        porta_com_frame = None

        for porta in portas:
            teste = None
            try:
                teste = serial_mod.Serial(
                    port=porta,
                    baudrate=self.baudrate,
                    timeout=0.20,
                )

                # Nano/ESP32 normalmente reiniciam quando a porta e aberta.
                limite = perf_counter() + 3.0
                while perf_counter() < limite:
                    bruto = teste.readline()
                    if not bruto:
                        continue

                    linha = bruto.decode("utf-8", errors="replace").strip()
                    if not linha:
                        continue

                    if self.MARCADOR_RECEPTOR in linha:
                        print(f"Receptor CAN identificado em {porta}: {linha}")
                        return porta

                    if porta_com_frame is None and self._parse_linha(linha) is not None:
                        porta_com_frame = porta

            except Exception as exc:
                print(f"Nao foi possivel testar {porta}: {exc}")
            finally:
                if teste is not None:
                    try:
                        teste.close()
                    except Exception:
                        pass

        if porta_com_frame is not None:
            print(
                "Firmware sem marcador, mas frames CAN validos foram detectados em "
                f"{porta_com_frame}."
            )
            return porta_com_frame

        raise RuntimeError(
            "Nao foi possivel identificar automaticamente o receptor CAN. "
            "Defina SERIAL_PORT explicitamente em configuracao.py e confirme "
            "que o firmware receptor foi gravado corretamente."
        )

    def conectar(self):
        try:
            import serial
            from serial.tools import list_ports
        except ImportError as exc:
            raise RuntimeError("Instale pyserial: pip install pyserial") from exc

        porta = self.porta
        if str(porta).lower().strip() == "auto":
            porta = self._detectar_receptor(serial, list_ports)

        self.serial = serial.Serial(
            port=porta,
            baudrate=self.baudrate,
            timeout=SERIAL_TIMEOUT_S,
        )
        self.inicio = perf_counter()

        # Aguarda boot/reset do Arduino/ESP32. Nao limpa o buffer depois disso,
        # porque os primeiros frames CAN recebidos tambem sao validos.
        sleep(1.5)
        print(f"Serial do receptor conectada: {porta} @ {self.baudrate} baud")

    @staticmethod
    def _hex_bytes(texto):
        tokens = re.findall(r"\b[0-9A-Fa-f]{2}\b", texto)
        return bytes(int(t, 16) for t in tokens)

    @classmethod
    def _parse_linha(cls, linha):
        linha = linha.strip()
        if not linha:
            return None

        # candump/SLCAN simplificado: 123#11223344
        m = re.search(r"(?:0x)?([0-9A-Fa-f]{1,8})#([0-9A-Fa-f]*)", linha)
        if m:
            can_id = int(m.group(1), 16)
            hex_data = m.group(2)
            if len(hex_data) % 2 != 0:
                return None
            dados = bytes.fromhex(hex_data)
            if len(dados) > 8:
                return None
            return can_id, dados

        # Formato oficial deste pacote:
        # ID=0x120 DLC=6 DATA=18 44 23 F0 00 00
        m = re.search(
            r"\bID\s*[:=]\s*(0x[0-9A-Fa-f]+|[0-9A-Fa-f]+).*?"
            r"\bDLC\s*[:=]\s*(\d+).*?"
            r"\bDATA\s*[:=]\s*([0-9A-Fa-fxX ,;:\-]*)",
            linha,
            flags=re.IGNORECASE,
        )
        if m:
            can_id = int(m.group(1), 16)
            dlc = int(m.group(2))
            dados = cls._hex_bytes(m.group(3).replace("0x", "").replace("0X", ""))
            if not (0 <= dlc <= 8):
                return None
            if len(dados) != dlc:
                return None
            return can_id, dados

        # Compatibilidade com formato antigo sem DLC no regex principal.
        m = re.search(
            r"\bID\s*[:=]\s*(0x[0-9A-Fa-f]+|[0-9A-Fa-f]+).*?"
            r"\bDATA\s*[:=]\s*([0-9A-Fa-fxX ,;:\-]+)",
            linha,
            flags=re.IGNORECASE,
        )
        if m:
            can_id = int(m.group(1), 16)
            dados = cls._hex_bytes(m.group(2).replace("0x", "").replace("0X", ""))
            if len(dados) <= 8:
                return can_id, dados

        # Formato simples: 0x123 8 11 22 33 44 55 66 77 88
        partes = linha.replace(",", " ").replace(";", " ").split()
        if len(partes) >= 2:
            try:
                id_txt = partes[0]
                if id_txt.lower().startswith("0x"):
                    can_id = int(id_txt, 16)
                elif re.fullmatch(r"[0-9A-Fa-f]{1,8}", id_txt):
                    can_id = int(id_txt, 16)
                else:
                    return None

                idx_dados = 1
                dlc = None
                if re.fullmatch(r"\d{1,2}", partes[1]):
                    dlc = int(partes[1])
                    if 0 <= dlc <= 8:
                        idx_dados = 2

                dados_txt = " ".join(partes[idx_dados:])
                dados = cls._hex_bytes(dados_txt.replace("0x", "").replace("0X", ""))
                if len(dados) > 8:
                    return None
                if dlc is not None and len(dados) != dlc:
                    return None
                if dados or dlc == 0:
                    return can_id, dados
            except (ValueError, IndexError):
                pass

        return None

    def receber(self):
        if self.serial is None:
            return None

        bruto = self.serial.readline()
        if not bruto:
            return None

        linha = bruto.decode("utf-8", errors="replace").strip()
        parsed = self._parse_linha(linha)
        if parsed is None:
            # Mostra somente mensagens relevantes de inicializacao/erro/status.
            if linha and (
                linha.startswith("ERRO")
                or linha.startswith("TCC_")
                or linha.startswith("[STATUS]")
                or "MCP2515" in linha
            ):
                print(f"[SERIAL RX] {linha}")
            return None

        can_id, dados = parsed
        return MensagemCAN(
            timestamp=perf_counter() - self.inicio,
            can_id=can_id,
            dados=dados,
        )

    def desconectar(self):
        if self.serial is not None:
            try:
                self.serial.close()
            except Exception:
                pass
            self.serial = None


class InterfacePythonCAN(InterfaceCAN):
    def __init__(self, interface, channel):
        self.interface = interface
        self.channel = channel
        self.bus = None

    def conectar(self):
        try:
            import can
        except ImportError as exc:
            raise RuntimeError("Instale python-can: pip install python-can") from exc
        self.bus = can.Bus(interface=self.interface, channel=self.channel, bitrate=BITRATE)
        self.inicio = perf_counter()

    def receber(self):
        msg = self.bus.recv(timeout=0.1)
        if msg is None:
            return None
        return MensagemCAN(
            perf_counter() - self.inicio,
            int(msg.arbitration_id),
            bytes(msg.data),
        )

    def desconectar(self):
        if self.bus is not None:
            try:
                self.bus.shutdown()
            except Exception:
                pass


def criar_interface():
    modo = MODO_CAN.lower().strip()
    if modo == "simulado":
        return InterfaceSimulada()
    if modo == "serial":
        return InterfaceSerial(SERIAL_PORT, SERIAL_BAUDRATE)
    if modo == "socketcan":
        return InterfacePythonCAN(SOCKETCAN_INTERFACE, SOCKETCAN_CHANNEL)
    if modo == "pcan":
        return InterfacePythonCAN("pcan", "PCAN_USBBUS1")
    if modo == "kvaser":
        return InterfacePythonCAN("kvaser", 0)
    if modo == "vector":
        return InterfacePythonCAN("vector", 0)
    raise ValueError(f"Modo CAN desconhecido: {MODO_CAN}")
