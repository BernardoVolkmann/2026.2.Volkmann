from dataclasses import dataclass
from time import perf_counter_ns
import os
import hashlib
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.asymmetric import rsa, ec, padding
from cryptography.hazmat.primitives import hashes

@dataclass
class ResultadoCriptografia:
    algoritmo: str
    latencia_us: float
    bytes_entrada: int
    bytes_saida: int
    throughput_mb_s: float
    sucesso: bool
    erro: str = ""

class MotorCriptografia:
    def __init__(self):
        self.chave_aes = os.urandom(16)
        self.chave_chacha = os.urandom(32)
        self.rsa_privada = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        self.rsa_publica = self.rsa_privada.public_key()
        self.ec_privada_a = ec.generate_private_key(ec.SECP256R1())
        self.ec_privada_b = ec.generate_private_key(ec.SECP256R1())
        self.ec_publica_b = self.ec_privada_b.public_key()

    def _resultado(self, nome, inicio, dados, saida, sucesso=True, erro=""):
        latencia = (perf_counter_ns() - inicio) / 1000.0
        segundos = latencia / 1_000_000.0
        throughput = (len(dados) / (1024 * 1024)) / segundos if segundos > 0 else 0.0
        return ResultadoCriptografia(nome, latencia, len(dados), len(saida), throughput, sucesso, erro)

    def aes(self, dados):
        inicio = perf_counter_ns()
        try:
            iv = os.urandom(16)
            enc = Cipher(algorithms.AES(self.chave_aes), modes.CTR(iv)).encryptor()
            saida = enc.update(dados) + enc.finalize()
            return self._resultado("AES-128-CTR", inicio, dados, saida)
        except Exception as e:
            return self._resultado("AES-128-CTR", inicio, dados, b"", False, str(e))

    def chacha(self, dados):
        inicio = perf_counter_ns()
        try:
            nonce = os.urandom(16)
            enc = Cipher(algorithms.ChaCha20(self.chave_chacha, nonce), mode=None).encryptor()
            saida = enc.update(dados)
            return self._resultado("ChaCha20", inicio, dados, saida)
        except Exception as e:
            return self._resultado("ChaCha20", inicio, dados, b"", False, str(e))

    def rsa(self, dados):
        inicio = perf_counter_ns()
        try:
            saida = self.rsa_publica.encrypt(
                dados,
                padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
            )
            return self._resultado("RSA-2048-OAEP", inicio, dados, saida)
        except Exception as e:
            return self._resultado("RSA-2048-OAEP", inicio, dados, b"", False, str(e))

    def ecies(self, dados):
        inicio = perf_counter_ns()
        try:
            segredo = self.ec_privada_a.exchange(ec.ECDH(), self.ec_publica_b)
            chave = hashlib.sha256(segredo).digest()[:16]
            iv = os.urandom(12)
            enc = Cipher(algorithms.AES(chave), modes.GCM(iv)).encryptor()
            ciphertext = enc.update(dados) + enc.finalize()
            saida = ciphertext + enc.tag
            return self._resultado("ECIES-P256", inicio, dados, saida)
        except Exception as e:
            return self._resultado("ECIES-P256", inicio, dados, b"", False, str(e))

    def processar(self, dados):
        return [self.aes(dados), self.chacha(dados), self.rsa(dados), self.ecies(dados)]
