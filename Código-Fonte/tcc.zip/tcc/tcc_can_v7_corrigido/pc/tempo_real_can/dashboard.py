from collections import deque
import queue
import matplotlib.pyplot as plt
from configuracao import JANELA_GRAFICO, INTERVALO_ATUALIZACAO_MS


class DashboardTempoReal:
    def __init__(self, fila):
        self.fila = fila
        self.algoritmos = ["AES-128-CTR", "ChaCha20", "RSA-2048-OAEP", "ECIES-P256"]
        self.frames = deque(maxlen=JANELA_GRAFICO)
        self.intervalos = deque(maxlen=JANELA_GRAFICO)
        self.latencias = {a: deque(maxlen=JANELA_GRAFICO) for a in self.algoritmos}
        self.throughputs = {a: deque(maxlen=JANELA_GRAFICO) for a in self.algoritmos}

        self.fig, self.axes = plt.subplots(3, 1, figsize=(12, 9))
        self.ax_lat, self.ax_thr, self.ax_can = self.axes
        self.lin_lat = {}
        self.lin_thr = {}

        for a in self.algoritmos:
            self.lin_lat[a], = self.ax_lat.plot([], [], label=a)
            self.lin_thr[a], = self.ax_thr.plot([], [], label=a)

        self.lin_can, = self.ax_can.plot([], [], label="Intervalo CAN")

        self.ax_lat.set_title("Latencia criptografica em tempo real")
        self.ax_lat.set_ylabel("Latencia (us)")
        self.ax_thr.set_title("Throughput criptografico em tempo real")
        self.ax_thr.set_ylabel("Throughput (MB/s)")
        self.ax_can.set_title("Intervalo entre frames CAN")
        self.ax_can.set_ylabel("Intervalo (us)")
        self.ax_can.set_xlabel("Frame recebido")

        for ax in self.axes:
            ax.grid(alpha=0.3)
        self.ax_lat.legend(loc="upper left")
        self.ax_thr.legend(loc="upper left")

        self.fig.suptitle("Monitoramento CAN em tempo real - aguardando frames...")
        self.fig.tight_layout(rect=[0, 0, 1, 0.96])

        # Timer do proprio canvas e mais confiavel para atualizacao continua que
        # FuncAnimation em diferentes backends (TkAgg, QtAgg etc.).
        self.timer = self.fig.canvas.new_timer(interval=INTERVALO_ATUALIZACAO_MS)
        self.timer.add_callback(self._tick)

    def _consumir(self):
        consumidos = 0
        while True:
            try:
                p = self.fila.get_nowait()
            except queue.Empty:
                break

            # Permite que a thread de captura comunique erros sem derrubar a GUI.
            if "erro" in p:
                self.fig.suptitle(f"Erro na captura CAN: {p['erro']}")
                print(f"[ERRO CAPTURA] {p['erro']}")
                continue

            self.frames.append(p["numero_frame"])
            self.intervalos.append(p["intervalo_us"])
            mapa = {r.algoritmo: r for r in p["resultados"]}

            for a in self.algoritmos:
                r = mapa.get(a)
                if r is None:
                    self.latencias[a].append(float("nan"))
                    self.throughputs[a].append(float("nan"))
                else:
                    self.latencias[a].append(r.latencia_us)
                    self.throughputs[a].append(r.throughput_mb_s)

            consumidos += 1

        return consumidos

    def _tick(self):
        try:
            consumidos = self._consumir()
            if not self.frames:
                self.fig.canvas.draw_idle()
                return True

            x = list(self.frames)
            for a in self.algoritmos:
                self.lin_lat[a].set_data(x, list(self.latencias[a]))
                self.lin_thr[a].set_data(x, list(self.throughputs[a]))

            self.lin_can.set_data(x, list(self.intervalos))

            for ax in self.axes:
                ax.relim()
                ax.autoscale_view()

            ultimo = self.frames[-1]
            self.fig.suptitle(
                f"Monitoramento CAN em tempo real - frame {ultimo}"
                + (f" (+{consumidos})" if consumidos else "")
            )

            # draw_idle agenda o redraw sem bloquear a thread da interface grafica.
            self.fig.canvas.draw_idle()
            return True
        except Exception as exc:
            print(f"[ERRO DASHBOARD] {type(exc).__name__}: {exc}")
            return True

    def iniciar(self):
        self.timer.start()
        try:
            plt.show()
        finally:
            self.timer.stop()
