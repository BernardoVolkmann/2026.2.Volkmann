from serial.tools import list_ports

portas = list(list_ports.comports())
if not portas:
    print("Nenhuma porta serial encontrada.")
else:
    print("Portas seriais encontradas:")
    for p in portas:
        print(f"  {p.device:<20} {p.description}")
