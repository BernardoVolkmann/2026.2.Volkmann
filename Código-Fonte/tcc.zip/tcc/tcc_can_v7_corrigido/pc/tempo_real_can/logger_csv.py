import csv
import os
from pathlib import Path
from datetime import datetime

CABECALHO = [
    "DataHora", "Timestamp_s", "IntervaloCAN_us", "CAN_ID", "DLC", "Dados_HEX",
    "Algoritmo", "Latencia_us", "Throughput_MB_s", "BytesEntrada", "BytesSaida",
    "Sucesso", "Erro"
]


class LoggerCSV:
    def __init__(self, caminho):
        self.caminho = Path(caminho).resolve()
        self.caminho.parent.mkdir(parents=True, exist_ok=True)
        novo = not self.caminho.exists() or self.caminho.stat().st_size == 0


        self.arquivo = self.caminho.open(
            "a", newline="", encoding="utf-8", buffering=1
        )
        self.writer = csv.writer(self.arquivo)

        if novo:
            self.writer.writerow(CABECALHO)
            self._persistir()

        print(f"CSV em tempo real: {self.caminho}")

    def _persistir(self):
        self.arquivo.flush()
        
        try:
            os.fsync(self.arquivo.fileno())
        except OSError:
            pass

    def registrar(self, mensagem, intervalo_us, r):
        self.writer.writerow([
            datetime.now().isoformat(timespec="milliseconds"),
            f"{mensagem.timestamp:.6f}",
            f"{intervalo_us:.3f}",
            f"0x{mensagem.can_id:X}",
            mensagem.dlc,
            mensagem.dados.hex(" ").upper(),
            r.algoritmo,
            f"{r.latencia_us:.6f}",
            f"{r.throughput_mb_s:.6f}",
            r.bytes_entrada,
            r.bytes_saida,
            int(r.sucesso),
            r.erro,
        ])
        self._persistir()

    def fechar(self):
        if getattr(self, "arquivo", None) is not None and not self.arquivo.closed:
            self._persistir()
            self.arquivo.close()
