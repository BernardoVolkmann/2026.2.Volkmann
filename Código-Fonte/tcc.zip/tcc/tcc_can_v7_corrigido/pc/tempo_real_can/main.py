import queue
import threading
import traceback

from can_interface import criar_interface
from criptografia import MotorCriptografia
from dashboard import DashboardTempoReal
from logger_csv import LoggerCSV
from configuracao import ARQUIVO_CSV


def capturar(fila, parar):
    interface = None
    logger = None

    try:
        interface = criar_interface()
        crypto = MotorCriptografia()
        logger = LoggerCSV(ARQUIVO_CSV)

        interface.conectar()
        print("Captura CAN em tempo real iniciada.")

        ultimo = None
        numero = 0

        while not parar.is_set():
            msg = interface.receber()
            if msg is None:
                continue

            numero += 1
            intervalo = 0.0 if ultimo is None else (msg.timestamp - ultimo) * 1_000_000.0
            ultimo = msg.timestamp

            
            resultados = crypto.processar(msg.dados)

            
            for r in resultados:
                logger.registrar(msg, intervalo, r)

            fila.put({
                "numero_frame": numero,
                "intervalo_us": intervalo,
                "resultados": resultados,
            })

            print(
                f"Frame {numero} | ID=0x{msg.can_id:X} | DLC={msg.dlc} | "
                f"DATA={msg.dados.hex(' ').upper()}"
            )

    except Exception as exc:
        mensagem = f"{type(exc).__name__}: {exc}"
        print("\nERRO NA THREAD DE CAPTURA:")
        traceback.print_exc()
        try:
            fila.put({"erro": mensagem})
        except Exception:
            pass
    finally:
        if interface is not None:
            try:
                interface.desconectar()
            except Exception:
                pass
        if logger is not None:
            try:
                logger.fechar()
            except Exception:
                pass


def main():
    fila = queue.Queue()
    parar = threading.Event()

    thread = threading.Thread(
        target=capturar,
        args=(fila, parar),
        name="captura-can",
        daemon=False,
    )
    thread.start()

    try:
        DashboardTempoReal(fila).iniciar()
    finally:
        parar.set()
        thread.join(timeout=3)
        if thread.is_alive():
            print("Aviso: thread de captura ainda estava encerrando ao fechar a janela.")


if __name__ == "__main__":
    main()
