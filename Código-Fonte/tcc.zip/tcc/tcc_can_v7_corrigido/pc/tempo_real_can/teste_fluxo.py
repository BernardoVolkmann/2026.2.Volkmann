"""Teste rapido sem hardware: valida parser, criptografia e gravacao do CSV."""
from pathlib import Path
from can_interface import InterfaceSerial, MensagemCAN
from criptografia import MotorCriptografia
from logger_csv import LoggerCSV

saida = Path(__file__).resolve().parent / "resultados" / "teste_fluxo.csv"
if saida.exists():
    saida.unlink()

linha = "ID=0x123 DLC=8 DATA=11 22 33 44 55 66 77 88"
parsed = InterfaceSerial._parse_linha(linha)
assert parsed is not None, "Parser serial nao reconheceu o frame de teste"
can_id, dados = parsed
assert can_id == 0x123
assert dados == bytes.fromhex("11 22 33 44 55 66 77 88")

msg = MensagemCAN(timestamp=1.0, can_id=can_id, dados=dados)
resultados = MotorCriptografia().processar(dados)
assert len(resultados) == 4

logger = LoggerCSV(saida)
for r in resultados:
    logger.registrar(msg, 0.0, r)
logger.fechar()

linhas = saida.read_text(encoding="utf-8").splitlines()
assert len(linhas) == 5, f"Esperava cabecalho + 4 registros, obtido {len(linhas)}"
print("OK - parser serial")
print("OK - criptografia")
print("OK - CSV gravado em tempo real")
print(f"Arquivo de teste: {saida}")
