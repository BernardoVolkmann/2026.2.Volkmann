"""Teste minimo da ponte CAN->USB, sem abrir o dashboard."""

from can_interface import criar_interface


def main():
    interface = criar_interface()
    interface.conectar()
    print("\nAguardando 20 frames CAN reais do receptor...\n")

    recebidos = 0
    try:
        while recebidos < 20:
            msg = interface.receber()
            if msg is None:
                continue
            recebidos += 1
            print(
                f"{recebidos:02d} | ID=0x{msg.can_id:X} | DLC={msg.dlc} | "
                f"DATA={msg.dados.hex(' ').upper()}"
            )
    finally:
        interface.desconectar()

    print("\nOK: a cadeia MCP2515 RX -> microcontrolador -> USB -> Python esta funcionando.")


if __name__ == "__main__":
    main()
